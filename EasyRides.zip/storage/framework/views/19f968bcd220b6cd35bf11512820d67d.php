<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lyft - Your Trusted Delivery Partner</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #006400;
            --secondary-color: #333333;
        }
        body {
            background-color: #ffffff;
            color: var(--secondary-color);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .navbar {
            background-color: #ffffff !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 1rem 2rem;
        }
        .navbar-brand {
            color: var(--primary-color) !important;
            font-weight: bold;
            font-size: 1.5rem;
        }
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1601600576337-c1d8a0d1373c?ixlib=rb-4.0.3');
            background-size: cover;
            background-position: center;
            padding: 150px 0;
            text-align: center;
            color: white;
        }
        .hero-section h1 {
            font-weight: 800;
            font-size: 3.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }
        .hero-section p {
            font-size: 1.5rem;
            font-weight: 500;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
        }
        .feature-card {
            background-color: #ffffff;
            border: none;
            border-radius: 10px;
            padding: 2rem;
            margin-bottom: 2rem;
            transition: transform 0.3s ease;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .feature-card img {
            height: 200px;
            object-fit: cover;
            width: 100%;
        }
        .feature-card:hover {
            transform: translateY(-5px);
        }
        .feature-icon {
            color: var(--primary-color);
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }
        .btn-success {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            padding: 10px 30px;
        }
        .btn-success:hover {
            background-color: #005000;
            border-color: #005000;
        }
        .btn-outline-success {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-success:hover {
            background-color: var(--primary-color);
            color: white;
        }
        .how-it-works {
            background-color: #f8f9fa;
            padding: 80px 0;
        }
        .step-number {
            background-color: var(--primary-color);
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
        }
        .services-section {
            padding: 80px 0;
            background-color: #ffffff;
        }
        .service-card {
            text-align: center;
            margin-bottom: 30px;
        }
        .service-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        footer {
            background-color: var(--primary-color);
            color: white;
            padding: 40px 0;
            margin-top: auto;
        }
        footer a {
            color: white;
            text-decoration: none;
        }
        footer a:hover {
            color: #f8f9fa;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <i class="fas fa-truck-fast me-2"></i>Lyft
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <div class="d-flex">
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-success me-2">Login</a>
                            <a href="<?php echo e(route('register')); ?>" class="btn btn-success">Register</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="hero-section">
        <div class="container">
            <h1>Fast & Reliable Delivery Service</h1>
            <p class="mb-5">Your trusted partner for seamless deliveries across Sri Lanka</p>
            <div class="d-flex justify-content-center gap-3">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light btn-lg">Login</a>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-success btn-lg">Register</a>
            </div>
        </div>
    </section>

    <section class="features py-5">
        <div class="container">
            <h2 class="text-center mb-5">Why Choose Lyft?</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="feature-card text-center">
                        <i class="fas fa-bolt feature-icon"></i>
                        <h4>Fast Delivery</h4>
                        <p>Quick and efficient delivery service to meet your deadlines</p>
                        <img src="https://cdn.prod.website-files.com/637d6390b70424b49c14ff1e/66066981f2d884346df02cbc_deliver-packages-faster-HERO.webp" class="img-fluid rounded mt-3" alt="Fast Delivery">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card text-center">
                        <i class="fas fa-shield-alt feature-icon"></i>
                        <h4>Secure Handling</h4>
                        <p>Your packages are handled with utmost care and security</p>
                        <img src="https://4623783.fs1.hubspotusercontent-na1.net/hub/4623783/hubfs/What%20is%20small%20parcel%20delivery.jpg?height=630&name=What%20is%20small%20parcel%20delivery.jpg" class="img-fluid rounded mt-3" alt="Secure Handling">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card text-center">
                        <i class="fas fa-map-marked-alt feature-icon"></i>
                        <h4>Real-time Tracking</h4>
                        <p>Track your deliveries in real-time with our advanced system</p>
                        <img src="https://go2stream.com/wp-content/uploads/2024/02/Stream-Go-Tracking-IDs-Tracking-Widget-Delivery-Order-Collection.png" class="img-fluid rounded mt-3" alt="Real-time Tracking">
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="how-it-works">
        <div class="container">
            <h2 class="text-center mb-5">How It Works</h2>
            <div class="row">
                <div class="col-md-4 text-center">
                    <div class="step-number">1</div>
                    <h4>Register</h4>
                    <p>Create your account in minutes</p>
                </div>
                <div class="col-md-4 text-center">
                    <div class="step-number">2</div>
                    <h4>Book Delivery</h4>
                    <p>Enter pickup and delivery details</p>
                </div>
                <div class="col-md-4 text-center">
                    <div class="step-number">3</div>
                    <h4>Track & Receive</h4>
                    <p>Monitor your delivery in real-time</p>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>About Lyft</h5>
                    <p>Your trusted delivery partner in Sri Lanka, ensuring fast and secure delivery services across the country.</p>
                </div>
                <div class="col-md-6">
                    <h5>Contact Us</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-phone me-2"></i> +94 11 234 5678</li>
                        <li><i class="fas fa-envelope me-2"></i> info@lyft.lk</li>
                        <li><i class="fas fa-map-marker-alt me-2"></i> 123 Galle Road, Colombo 03, Sri Lanka</li>
                    </ul>
                </div>
            </div>
            <hr class="mt-4 mb-4" style="border-color: rgba(255,255,255,0.1);">
            <div class="text-center">
                <p class="mb-0">&copy; 2025 Lyft. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel_project\lyft\resources\views/welcome.blade.php ENDPATH**/ ?>