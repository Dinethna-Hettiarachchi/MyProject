<?php $__env->startSection('title', 'Dashboard - Lyft'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="rounded-circle p-2 me-2" style="background-color: #006400;">
                            <i class="fas fa-user text-white"></i>
                        </div>
                        <div>
                            <h6 class="mb-0"><?php echo e(Auth::user()->name); ?></h6>
                            <small class="text-muted">Customer</small>
                        </div>
                    </div>
                    <hr>
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2">
                            <a href="#" class="nav-link text-dark active">
                                <i class="fas fa-home me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a href="<?php echo e(route('orders.index')); ?>" class="nav-link text-dark">
                                <i class="fas fa-box me-2"></i> My Orders
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link text-dark">
                                <i class="fas fa-user me-2"></i> Profile
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <!-- Welcome Message -->
            <div class="card mb-4">
                <div class="card-body">
                    <h4 class="mb-3" style="color: #006400;">Welcome to Lyft Delivery!</h4>
                    <p>Thank you for joining our delivery platform. We're here to make your delivery experience smooth and efficient.</p>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title" style="color: #006400;">
                                <i class="fas fa-plus-circle me-2"></i>New Order
                            </h5>
                            <p class="card-text">Create a new delivery order quickly and easily.</p>
                            <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-outline-success">Create Order</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title" style="color: #006400;">
                                <i class="fas fa-truck me-2"></i>Track Order
                            </h5>
                            <p class="card-text">Track your current delivery in real-time.</p>
                            <a href="#" class="btn btn-outline-success">Track Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title" style="color: #006400;">
                                <i class="fas fa-history me-2"></i>Order History
                            </h5>
                            <p class="card-text">View your past orders and delivery history.</p>
                            <a href="#" class="btn btn-outline-success">View History</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0" style="color: #006400;">Recent Orders</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="4" class="text-center">No recent orders</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_project\lyft\resources\views/dashboard.blade.php ENDPATH**/ ?>