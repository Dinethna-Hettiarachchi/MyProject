<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="mb-0" style="color: #006400;">Order #<?php echo e($order->id); ?></h4>
                        <div>
                            <?php if($order->status === 'pending'): ?>
                                <form action="<?php echo e(route('orders.destroy', $order)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-outline-danger" onclick="return confirm('Are you sure you want to cancel this order?')">
                                        <i class="fas fa-times me-1"></i> Cancel Order
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5 class="text-muted mb-3">Order Details</h5>
                            <p class="mb-1"><strong>Status:</strong>
                                <?php switch($order->status):
                                    case ('pending'): ?>
                                        <span class="badge bg-warning text-dark">Pending</span>
                                        <?php break; ?>
                                    <?php case ('accepted'): ?>
                                        <span class="badge bg-info">Accepted</span>
                                        <?php break; ?>
                                    <?php case ('in_transit'): ?>
                                        <span class="badge bg-primary">In Transit</span>
                                        <?php break; ?>
                                    <?php case ('delivered'): ?>
                                        <span class="badge bg-success">Delivered</span>
                                        <?php break; ?>
                                    <?php case ('cancelled'): ?>
                                        <span class="badge bg-danger">Cancelled</span>
                                        <?php break; ?>
                                <?php endswitch; ?>
                            </p>
                            <p class="mb-1"><strong>Created:</strong> <?php echo e($order->created_at->format('M d, Y H:i')); ?></p>
                            <p class="mb-1"><strong>Last Updated:</strong> <?php echo e($order->updated_at->format('M d, Y H:i')); ?></p>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="card bg-light">
                                <div class="card-body">
                                    <h6 class="card-title"><i class="fas fa-map-marker-alt me-2"></i>Pickup Address</h6>
                                    <p class="card-text"><?php echo e($order->pickup_address); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card bg-light">
                                <div class="card-body">
                                    <h6 class="card-title"><i class="fas fa-flag-checkered me-2"></i>Delivery Address</h6>
                                    <p class="card-text"><?php echo e($order->delivery_address); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card bg-light mb-4">
                        <div class="card-body">
                            <h6 class="card-title"><i class="fas fa-box me-2"></i>Package Description</h6>
                            <p class="card-text"><?php echo e($order->package_description); ?></p>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-1"></i> Back to Orders
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .card {
        border: none;
        box-shadow: 0 0 15px rgba(0,0,0,0.05);
        border-radius: 10px;
    }
    .card-header {
        border-bottom: 1px solid rgba(0,0,0,0.1);
        padding: 20px;
    }
    .badge {
        padding: 0.5em 1em;
    }
    .btn-success {
        background-color: #006400;
        border-color: #006400;
    }
    .btn-success:hover {
        background-color: #005000;
        border-color: #005000;
    }
    .btn-outline-success {
        color: #006400;
        border-color: #006400;
    }
    .btn-outline-success:hover {
        background-color: #006400;
        border-color: #006400;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_project\lyft\resources\views/orders/show.blade.php ENDPATH**/ ?>