<?php $__env->startSection('title', 'Dashboard - EasyRides'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="card sidebar-card">
                <div class="card-body">
                    <div class="user-profile text-center mb-4">
                        <div class="avatar-circle mb-3">
                            <i class="fas fa-user"></i>
                        </div>
                        <h5 class="mb-1"><?php echo e(Auth::user()->name); ?></h5>
                        <span class="badge bg-primary">Premium Member</span>
                    </div>
                    <hr>
                    <ul class="nav flex-column nav-pills">
                        <li class="nav-item mb-2">
                            <a href="#" class="nav-link active">
                                <i class="fas fa-home me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a href="<?php echo e(route('orders.index')); ?>" class="nav-link">
                                <i class="fas fa-car me-2"></i> My Rides
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link">
                                <i class="fas fa-user me-2"></i> Profile
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <!-- Welcome Banner -->
            <div class="welcome-banner mb-4">
                <div class="banner-content">
                    <h2>Welcome to EasyRides!</h2>
                    <p>Experience premium vehicle hiring service at your fingertips.</p>
                    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-light">Book a Ride <i class="fas fa-arrow-right ms-2"></i></a>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="quick-action-card">
                        <div class="icon-wrapper">
                            <i class="fas fa-plus-circle"></i>
                        </div>
                        <h4>New Ride</h4>
                        <p>Book a new ride instantly</p>
                        <a href="<?php echo e(route('orders.create')); ?>" class="stretched-link"></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="quick-action-card">
                        <div class="icon-wrapper">
                            <i class="fas fa-map-marked-alt"></i>
                        </div>
                        <h4>Track Ride</h4>
                        <p>Monitor your current ride</p>
                        <a href="#" class="stretched-link"></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="quick-action-card">
                        <div class="icon-wrapper">
                            <i class="fas fa-history"></i>
                        </div>
                        <h4>Ride History</h4>
                        <p>View your past rides</p>
                        <a href="#" class="stretched-link"></a>
                    </div>
                </div>
            </div>

            <!-- Recent Rides -->
            <div class="card recent-rides-card">
                <div class="card-header">
                    <h5 class="mb-0">Recent Rides</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Ride ID</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="4" class="text-center py-5">
                                        <div class="empty-state">
                                            <i class="fas fa-car-side"></i>
                                            <p>No recent rides</p>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Dashboard Styles */
    .sidebar-card {
        border: none;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(193, 101, 18, 0.1);
    }
    .avatar-circle {
        width: 80px;
        height: 80px;
        background-color: #c16512;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
    }
    .avatar-circle i {
        font-size: 2rem;
        color: white;
    }
    .badge.bg-primary {
        background-color: #c16512 !important;
        font-weight: 500;
        padding: 0.5em 1em;
    }
    .nav-pills .nav-link {
        color: #666;
        border-radius: 10px;
        padding: 0.8rem 1rem;
        transition: all 0.3s ease;
    }
    .nav-pills .nav-link:hover {
        color: #c16512;
        background-color: rgba(193, 101, 18, 0.1);
    }
    .nav-pills .nav-link.active {
        background-color: #c16512;
        color: white;
    }
    .welcome-banner {
        background: linear-gradient(135deg, #c16512, #e68a19);
        border-radius: 20px;
        padding: 2.5rem;
        color: white;
        position: relative;
        overflow: hidden;
    }
    .welcome-banner::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 300px;
        height: 100%;
        background: url('https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3') center/cover;
        opacity: 0.2;
    }
    .welcome-banner h2 {
        font-size: 2.2rem;
        font-weight: 700;
        margin-bottom: 1rem;
    }
    .welcome-banner p {
        font-size: 1.1rem;
        opacity: 0.9;
        margin-bottom: 1.5rem;
    }
    .quick-action-card {
        background: white;
        border-radius: 15px;
        padding: 1.5rem;
        text-align: center;
        position: relative;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(193, 101, 18, 0.1);
        cursor: pointer;
    }
    .quick-action-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(193, 101, 18, 0.2);
    }
    .quick-action-card .icon-wrapper {
        width: 60px;
        height: 60px;
        background-color: rgba(193, 101, 18, 0.1);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1rem;
    }
    .quick-action-card .icon-wrapper i {
        font-size: 1.5rem;
        color: #c16512;
    }
    .quick-action-card h4 {
        color: #333;
        font-size: 1.2rem;
        margin-bottom: 0.5rem;
    }
    .quick-action-card p {
        color: #666;
        margin-bottom: 0;
        font-size: 0.9rem;
    }
    .recent-rides-card {
        border: none;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(193, 101, 18, 0.1);
    }
    .recent-rides-card .card-header {
        background-color: white;
        border-bottom: 1px solid rgba(193, 101, 18, 0.1);
        padding: 1.2rem 1.5rem;
    }
    .recent-rides-card .card-header h5 {
        color: #c16512;
        font-weight: 600;
    }
    .empty-state {
        text-align: center;
        padding: 2rem;
    }
    .empty-state i {
        font-size: 3rem;
        color: #c16512;
        margin-bottom: 1rem;
    }
    .empty-state p {
        color: #666;
        margin-bottom: 0;
    }
    .table th {
        font-weight: 600;
        color: #333;
    }
    .table td {
        vertical-align: middle;
    }
    @media (max-width: 768px) {
        .welcome-banner {
            padding: 2rem;
        }
        .quick-action-card {
            margin-bottom: 1rem;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_project\lyft - Copy\resources\views/dashboard.blade.php ENDPATH**/ ?>