<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="card">
        <div class="card-header bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0" style="color: #006400;">My Orders</h4>
                <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-success">
                    <i class="fas fa-plus-circle me-1"></i> New Order
                </a>
            </div>
        </div>

        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if($orders->isEmpty()): ?>
                <div class="text-center py-5">
                    <i class="fas fa-box fa-3x mb-3" style="color: #006400;"></i>
                    <h5>No Orders Yet</h5>
                    <p class="text-muted">Create your first order to get started!</p>
                    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-success">
                        <i class="fas fa-plus-circle me-1"></i> Create Order
                    </a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Pickup</th>
                                <th>Delivery</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($order->id); ?></td>
                                    <td><?php echo e(Str::limit($order->pickup_address, 30)); ?></td>
                                    <td><?php echo e(Str::limit($order->delivery_address, 30)); ?></td>
                                    <td>
                                        <?php switch($order->status):
                                            case ('pending'): ?>
                                                <span class="badge bg-warning text-dark">Pending</span>
                                                <?php break; ?>
                                            <?php case ('accepted'): ?>
                                                <span class="badge bg-info">Accepted</span>
                                                <?php break; ?>
                                            <?php case ('in_transit'): ?>
                                                <span class="badge bg-primary">In Transit</span>
                                                <?php break; ?>
                                            <?php case ('delivered'): ?>
                                                <span class="badge bg-success">Delivered</span>
                                                <?php break; ?>
                                            <?php case ('cancelled'): ?>
                                                <span class="badge bg-danger">Cancelled</span>
                                                <?php break; ?>
                                        <?php endswitch; ?>
                                    </td>
                                    <td><?php echo e($order->created_at->format('M d, Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('orders.show', $order)); ?>" class="btn btn-sm btn-outline-success me-1">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if($order->status === 'pending'): ?>
                                            <form action="<?php echo e(route('orders.destroy', $order)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to cancel this order?')">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    .card {
        border: none;
        box-shadow: 0 0 15px rgba(0,0,0,0.05);
        border-radius: 10px;
    }
    .table th {
        border-top: none;
        color: #666;
        font-weight: 500;
    }
    .table td {
        vertical-align: middle;
    }
    .badge {
        padding: 0.5em 1em;
    }
    .btn-success {
        background-color: #006400;
        border-color: #006400;
    }
    .btn-success:hover {
        background-color: #005000;
        border-color: #005000;
    }
    .btn-outline-success {
        color: #006400;
        border-color: #006400;
    }
    .btn-outline-success:hover {
        background-color: #006400;
        border-color: #006400;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_project\lyft\resources\views/orders/index.blade.php ENDPATH**/ ?>