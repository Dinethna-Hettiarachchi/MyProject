@extends('layouts.app')

@section('title', 'My Rides - EasyRides')

@section('content')
<div class="container py-4">
    <div class="card">
        <div class="card-header bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0" style="color: #c16512;">My Rides</h4>
                <a href="{{ route('orders.create') }}" class="btn btn-success">
                    <i class="fas fa-plus-circle me-1"></i> New Ride
                </a>
            </div>
        </div>

        <div class="card-body">
            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            @if($orders->isEmpty())
                <div class="text-center py-5">
                    <i class="fas fa-box fa-3x mb-3" style="color: #c16512;"></i>
                    <h5>No Rides Yet</h5>
                    <p class="text-muted">Create your first ride to get started!</p>
                    <a href="{{ route('orders.create') }}" class="btn btn-success">
                        <i class="fas fa-plus-circle me-1"></i> Create Ride
                    </a>
                </div>
            @else
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Ride ID</th>
                                <th>Pickup</th>
                                <th>Delivery</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($orders as $order)
                                <tr>
                                    <td>#{{ $order->id }}</td>
                                    <td>{{ Str::limit($order->pickup_address, 30) }}</td>
                                    <td>{{ Str::limit($order->delivery_address, 30) }}</td>
                                    <td>
                                        @switch($order->status)
                                            @case('pending')
                                                <span class="badge bg-warning text-dark">Pending</span>
                                                @break
                                            @case('accepted')
                                                <span class="badge bg-info">Accepted</span>
                                                @break
                                            @case('in_transit')
                                                <span class="badge bg-primary">In Transit</span>
                                                @break
                                            @case('delivered')
                                                <span class="badge bg-success">Delivered</span>
                                                @break
                                            @case('cancelled')
                                                <span class="badge bg-danger">Cancelled</span>
                                                @break
                                        @endswitch
                                    </td>
                                    <td>{{ $order->created_at->format('M d, Y') }}</td>
                                    <td>
                                        <a href="{{ route('orders.show', $order) }}" class="btn btn-sm btn-outline-success me-1">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        @if($order->status === 'pending')
                                            <form action="{{ route('orders.destroy', $order) }}" method="POST" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to cancel this ride?')">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </form>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>
</div>

<style>
    .card {
        border: none;
        box-shadow: 0 0 15px rgba(0,0,0,0.05);
        border-radius: 10px;
    }
    .table th {
        border-top: none;
        color: #666;
        font-weight: 500;
    }
    .table td {
        vertical-align: middle;
    }
    .badge {
        padding: 0.5em 1em;
    }
    .btn-success {
        background-color: #c16512;
        border-color: #c16512;
    }
    .btn-success:hover {
        background-color: #a9560a;
        border-color: #a9560a;
    }
    .btn-outline-success {
        color: #c16512;
        border-color: #c16512;
    }
    .btn-outline-success:hover {
        background-color: #c16512;
        border-color: #c16512;
    }
</style>
@endsection
